package com.ecobookingplatform.ebp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbpApplicationTests {

	@Test
	void contextLoads() {
	}

}
